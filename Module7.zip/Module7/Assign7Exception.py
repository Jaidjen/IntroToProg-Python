'''
Module 7
Assignment 7
Diana Wright
Create a simple example of how you would use Python Exception Handling.
Make sure to comment your code.
'''
#This is a code to request the user to input a number that can be used to divide 10
#Use try-except statement for exception handling
#the try block contains code that might raise the exception
try:
    print("Please input two numbers to arrive at a quotient")
    print(" ")
    num_sam1= int(input("Please provide the first number: "))
    num_sam2= int(input("Please provide the second number:"))
    result = num_sam1/num_sam2
    print("The quotient between",str(num_sam1),"and",str(num_sam2),"is", result)

#if the user input is 0, it will print the error message that division by 0 is not possible
except ZeroDivisionError:
   # print("Exception Handler for ZeroDivisionError")
    print("ERROR: We cannot divide a number by 0")

#if the user input is not a number, it will print the error message to input numbers only
except ValueError:
    print("ERROR: Please input whole numbers only")

