'''
Module 7
Assignment 7
Diana Wright
Create a simple example of how you would use Python Pickling.
Make sure to comment your code
'''

#Import the pickle module
import pickle

#create dictionary called task
task={'clean house','cook dinner','do laundry'}

#create a pickle file to store the object
pickle_file= open("task.pickle","wb")

#store the object data to the file
pickle.dump(task,pickle_file)

#close the file
pickle_file.close()


#to retrieve the pickled data
#open the file where the pickled data was stored
pickle_op=open("task.pickle","rb")

#dump the information to that file
task=pickle.load(pickle_op)

#show the pickled data
print(task)
