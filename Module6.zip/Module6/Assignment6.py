dicRow1 = {"Clean House","low"}
dicRow2 ={"Pay Bills","high"}
lstTable= [dicRow1,dicRow2]
#4.	Display the contents of the List to the user.
print(lstTable)

#5.	Allow the user to Add or Remove tasks from the list using numbered choices.
while(True):
    print ("""
    Menu of Options
    1) Show current data
    2) Add a new item.
    3) Remove an existing item.
    4) Save Data to File
    5) Exit Program
    """)
    strChoice = str(input("Which option would you like to perform? [1 to 4] - "))
    print()#adding a new line\
    # Step 3 -Show the current items in the table
    if (strChoice.strip() == '1'):
        print(lstTable)
        continue
    # Step 4 - Add a new item to the list/Table
    elif(strChoice.strip() == '2'):
        strActivity = input ("Enter New Activity:  ")
        strPriority = input ("Enter New Priority:  ")
        dicNewRow = {strActivity,strPriority}
        lstTable.append(dicNewRow)
        print(lstTable)
        continue
    # Step 5 - Remove a new item to the list/Table
    elif(strChoice == '3'):
        lstTable.remove(dicNewRow)
        #print(lstTable)
        continue
    # Step 6 - Save tasks to the ToDo.txt file
    elif(strChoice == '4'):
        print("The Following Data was saved to a file")
        print(lstTable)
        objF=open("Desktop\ToDo.txt","a")
        objF.write((str)(lstTable))
        objF.close()
        continue
   # elif (strChoice == '5'):
      #  break #and Exit the program
